import matplotlib.pyplot as plt
import numpy as np
import random
from numpy.random import RandomState
from rabin_fingerprint import Rabin

def mutate_int(gene, genotype):
    ### increasing or decreasing decimal gene by 1
    plus_or_min = random.uniform(0, 1)

    if plus_or_min < 0.5:
        gene -= 1
    else:
        gene += 1

    # lower bound
    if gene < 2:
        gene = 2

    genotype.append(gene)
    return genotype


def mutate_genotype(genotype, p_mutation):
    genotype2 = []
    muteted_genes=[]
    print("Genotype mutation started")
    print(f"Genotype is {genotype}")
 
    ###cand = [size_of_pol,size_of_mask,p,window_size,mask,minsize,maxsize]
    ### enumerae adds counter to each element in genotype. Very convenient 
    for i,gene in enumerate(genotype):
        prob = random.uniform(0, 1)
        
        ### Mutating the size of polinomial
        if prob < p_mutation and i==0:
            genotype2=mutate_int(gene,genotype2)
            muteted_genes.append(i)
            print(f"Gene number {i} was mutated")

        
        ### Mutating the polynomial
        elif prob < p_mutation and i==1:

            degree = int(genotype2[0] - 1)
            
            bit = random.randint(0, degree - 1)

            ### 1<<bit creates a binary number, in which all bits are 0 except of bit 
            # number "bit". Then it perform XOR operation between gene (which is polinomial) 
            # and new binary number. It leaves all bit in gene the same except the one under 
            # number "bit" 

            new_pol=gene ^ (1 << bit)
            genotype2.append(new_pol)
            muteted_genes.append(i)
            print(f"Gene number {i} was mutated")
        
        ### Mutating the size of the window
        elif prob < p_mutation and i==2: 
            genotype2=mutate_int(gene,genotype2)
            muteted_genes.append(1)
            print(f"Gene number {i} was mutated")
        
        ### Mutating the mask
        elif prob < p_mutation and i==3:

            degree = genotype2[1] - 1
            bit = random.randint(0, degree - 1)

            ### Same as for the one for mutating polynomial

            new_pol=gene ^ (1 << bit)
            genotype2.append(new_pol)
            muteted_genes.append(1)
            print(f"Gene number {i} was mutated")

        ### Mutating the minimal size of the chunk. The mutatuin amount is 1 kb
        elif prob < p_mutation and i==4:
            plus_or_min = random.uniform(0, 1)
            if gene<10240 and plus_or_min<=0.5:
                gene=gene+1024
                muteted_genes.append(1)
                print(f"Gene number {i} was mutated")
            elif gene>=2048 and plus_or_min>=0.5:
                gene=gene-1024
                muteted_genes.append(1)
                print(f"Gene number {i} was mutated")

            genotype2.append(gene)
            muteted_genes.append(1)
            print(f"Gene number {i} was mutated")
        
        ### Mutating the maximal size of the chunk
        elif prob < p_mutation and i==5:
            plus_or_min = random.uniform(0, 1)
            ### Max size of the chunk should always be greater than min
            if gene<=genotype2[4]:
                gene=gene+1024
                muteted_genes.append(1)
                print(f"Gene number {i} was mutated")
            elif gene>=2048 and gene<=10240 and plus_or_min>=0.5:
                gene=gene+1024
                muteted_genes.append(1)
                print(f"Gene number {i} was mutated")

            elif gene<=10240 and gene-genotype2[4]>=2048  and plus_or_min<=0.5:
                gene=gene-1024
                muteted_genes.append(1)
                print(f"Gene number {i} was mutated")
            
            genotype2.append(gene)
            
        else:
            genotype2.append(gene)

    #####
    print(genotype2)
    ######        
    
    return muteted_genes, genotype2

def uniform_crossover(cand_loser, cand_winner, prob_csross, n_genes):
    copy_loser = cand_loser.copy()

    for i in range(n_genes):
        for j in range(n_genes):
            prob = random.uniform(0, 1)
            if prob < prob_csross:
                copy_loser[i] = cand_winner[i]
    return copy_loser

def tournament_selection(cand_1, cand_2):
    cand_1_fitness = ffunction1(cand_1)
    print(f"\nCand_1 is {cand_1}, it's fitness {cand_1_fitness}")
    cand_2_fitness = ffunction1(cand_2)
    print(f"Cand_2 is {cand_2}, it's fitness {cand_2_fitness}")
    if cand_1_fitness > cand_2_fitness:
        cand_winer = cand_1
        cand_loser = cand_2
    elif cand_1_fitness < cand_2_fitness:
        cand_winer = cand_2
        cand_loser = cand_1
    else:
        cand_winer = cand_1
        cand_loser = cand_2
    return cand_loser, cand_winer



def ffunction1(cand):
    ### activates rabin fingerprint. Percentage of saved space is fitness value
    rabin=Rabin()
    saved_space=rabin.start(cand)
    return saved_space

    

def netcrawler_accept(delta_f):
    if delta_f >= 0:
        return True
    else:
        return False
    
def HC_accept(delta_f):
    if delta_f > 0:
        return True
    else:
        return False
    
def SA_accept(delta_f, t):
    if delta_f > 0:
        return 1
    elif np.random.random() < np.exp(delta_f / t):
        return True
    else:
        return False

def generalised_hill_climber(fitness_target, iteration_max, p_mutation, cand):
    cand_best=cand
    fitness_best = ffunction1(cand_best)
    i = 0
    arr_i = []
    
    fitness_history = []
    positive_mutations=[]
    while fitness_best < fitness_target and i < iteration_max:

        #######
        print(f"\n\n\nStartig generation number {i}")
        ######

        muteted_gene, cand_mutated = mutate_genotype(cand_best, p_mutation)
        cand_loser, cand_winer = tournament_selection(
            cand_best, cand_mutated
        )
        cand_new = uniform_crossover(
            cand_loser=cand_loser,
            cand_winner=cand_winer,
            prob_csross=1 / 6,
            n_genes=6,
        )
        # cand_new = mutate_genotype(cand_best, p_mutation)

        fitness_new = ffunction1(cand_new)
        delta_fitness = fitness_new - fitness_best
        if netcrawler_accept(delta_fitness):
            cand_best = cand_new
            fitness_best = fitness_new
            fitness_history.append(fitness_new)
            arr_i.append(i)
            positive_mutations.append(muteted_gene)
        else:
            fitness_history.append(fitness_best)
            arr_i.append(i)
        
        

        # DO NOT TOUCH THIS
        i += 1
        # DO NOT TOUCH THIS

    return cand_best, fitness_best,fitness_history,positive_mutations


def random_polynomial(degree):
    
    
    p = (1 << degree) | 1

    
    n_terms = random.randint(1, degree - 1)

    bits = random.sample(range(1, degree), n_terms)
    for b in bits:
        p |= 1 << b

    return p

def main():
    print("Starting project")
    size_of_pol=40
    
    ### Starting polynomial is a binary number with each bit equal to 1
    p=0x1B
    window_size=16
    mask=(1 << 11) - 1
    minsize=1024 #1 kb
    maxsize=6144 #6 kb

    cand = [size_of_pol,p,window_size,mask,minsize,maxsize]

    print(f"Candidate is \n {cand}")
    p_mutation1 = 1 / 5
    arr_fit = []
    number_of_generations = 20
    n_runs = 0
    avg_fitnesses = np.zeros((1, 2))
    arr3 = []

    cand_best1, fitness_best1,fitness_history,positive_mutations = generalised_hill_climber(
        fitness_target=100,
        iteration_max=number_of_generations,
        p_mutation=p_mutation1,
        cand=cand,
    )
    
    plt.figure(figsize=(8,5))
    plt.plot(range(1, len(fitness_history)+1), fitness_history, marker='o')
    plt.xlabel("Generation")
    plt.ylabel("Fitness")
    plt.title("Fitness over Generations")
    plt.grid(True)
    plt.show()

    print(f"Positive mutations are: \n{positive_mutations}")
    print(f"Original candidate is {cand}, it's fitness is {ffunction1(cand)}")
    print(f"The best cand is {cand_best1}, it's fitness is {fitness_best1}")
    
      
if __name__ == "__main__":
   
    main()