
import hashlib
import os
import shutil

class Rabin:
    def __init__(self):
        
        self.file_structure=[]

        self.duplicates=0
        self.file_name='test_mid.html'

    def start(self,cand):
        ### Deleting chunks folder to delete all previous chunks 
        folder_chunk = "chunks"
        if os.path.exists(folder_chunk) and os.path.isdir(folder_chunk):
            shutil.rmtree(folder_chunk)  
            print(f"\nfolder {folder_chunk} is deleted ")
                
        else:
            print(f"\nfolder {folder_chunk} is not found")

       
        files = os.listdir('files')
        for file_name in files:
            file_path = os.path.join('files', file_name)
            with open(file_path, mode="rb") as file:
                print(f"file is {file_name}")
                read_file = file.read()
                

                ###assigning variabels for rabin fingerprint.
                # Element 0 is degree of polynomial, which is irrelevant for 
                # this function, so we start from element 1
                p = cand[1]
                window_size = cand[2]
                mask = cand[3]
                minsize = cand[4]
                maxsize = cand[5]
                
                
                self.rabin_fingerprint(read_file, p, window_size, mask, minsize, maxsize)
                

        ### Creating file with duplicated data for testing
        #self.create_dup_file()
        #file_name_dup="files/test_repeats.bin"

        #self.restore_file(file_name)
        space_saved=100-self.get_size("chunks")/self.get_size("files")*100
        print(f"Deduplication ratio: {self.get_size('files') / self.get_size('chunks'):.3f}")
        print(f"Space saved is {100-self.get_size('chunks')/self.get_size('files')*100:.2f}%")
        return space_saved
            

    def restore_file(self,file_name):
        ### Taking chunk names from file_structure, searching it in chunk 
        # folder and writing into new file 
        restored_file = bytearray()
        chunks_path = "chunks"

        for name in self.file_structure:
            chunk = os.path.join(chunks_path, name)
            if not os.path.exists(chunk):
                raise FileNotFoundError(f"Chunk {name} not found")
            with open(chunk, "rb") as f:
                restored_file.extend(f.read())

        new_file_name='restored_'+file_name        
        with open(new_file_name, "wb") as restored_f:
            restored_f.write(restored_file)
        print(f"{file_name} is restored as 'restored_{file_name}")
        



    def get_size(self,path):
        ###returns the size of a folder
        total_size = 0
        with os.scandir(path) as it:
            for entry in it:
                if entry.is_file(follow_symlinks=False):
                 
                    total_size += entry.stat(follow_symlinks=False).st_size
        return total_size
        

    def hash_chunk(self,chunk):
        ### Creating a unique name for each chunk
        return hashlib.sha256(b''.join(chunk)).hexdigest()

    def chunking(self,chunk):
     
        name=self.hash_chunk(chunk)
        folder = "chunks"
        os.makedirs(folder, exist_ok=True)
        file_path = os.path.join(folder, name)


        if os.path.exists(file_path):
            self.duplicates+=1
        else:
            with open(file_path, 'wb') as f:  
                f.write(b''.join(chunk))

        self.file_structure.append(name)



    def rabin_fingerprint(self,read_file,p,window_size,mask,minsize,maxsize):
         
        chunk=[]
        chunk_count=0

        for i in range(len(read_file)):
            ### taking bytes by index 0-8, 1-9...
            
            window=read_file[int(i):int(i)+int(window_size)]
            s=self.polynomial(window)
            fp = self.mod(s, p)
            chunk.append(read_file[i:i+1])

            if len(chunk) >= minsize and (fp & mask == 0):
                self.chunking(chunk)
                chunk = []
                chunk_count += 1

            elif len(chunk) >= maxsize:
                self.chunking(chunk)
                chunk = []
                chunk_count += 1

        ### If the last fingerprint triggers if fp&mask == 0 loop, if chunk will not 
        # work because chunk[] will be empty. Else it will create the last chunk
        if chunk:
            self.chunking(chunk)
            chunk_count += 1
        

                
      
    def polynomial(self,window):
        s=0
        ###takes a byte from window, moves existing bytes in polynomial to the left and adds new byte (not sum)
        for i in window:
            s=(s<<8)|i
        return s

    def mod(self,A, B):
        ### Mod in Galois field 2 (GF(2)) is different from regular polynomial division. In order to find the dividend
        # it is requred to use formula A=A^(B << (degree(A)-degree(B))) over and over again untill degree of A will 
        # not be less than degree of B.###
        A = int(A)
        B = int(B)
        while self.degree(A) >= self.degree(B):
            shift = self.degree(A) - self.degree(B)
            A ^= B << shift
        
        return A
    
    def degree(self,x):
        
        a=int(x).bit_length() - 1
    
        return a

