import numpy
import os
from numpy import random

class FileGenerator():

    def generate_test_file(self,filename,total_size, duplicate_percent):
     
        data = bytearray()

        duplicate_size = int(total_size * (duplicate_percent / 100))
        unique_size = total_size - duplicate_size

        duplicate_block = os.urandom(64)  

        while len(data) < duplicate_size:
            data.extend(duplicate_block)

        data = data[:duplicate_size]


        data.extend(os.urandom(unique_size))

        random.shuffle(data)
        file_path = os.path.join('files', filename)

        with open(file_path, mode="wb") as file:
            file.write(data)

    def gen_step_file(self,filename,total_size, duplicate_percent):
     
        data = bytearray()

        duplicate_size = int(total_size * (duplicate_percent / 100))
        unique_size = total_size - duplicate_size

        duplicate_block = os.urandom(64)  

        while len(data) < duplicate_size:
            data.extend(duplicate_block)

        data = data[:duplicate_size]


        data.extend(os.urandom(unique_size))

        random.shuffle(data)
        file_path = os.path.join('files', filename)

        with open(file_path, mode="wb") as file:
            file.write(data)