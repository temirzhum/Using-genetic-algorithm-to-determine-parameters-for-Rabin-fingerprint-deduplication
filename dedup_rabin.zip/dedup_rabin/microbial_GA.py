import evol_alg
import numpy as np
from numpy import random
from rabin_fingerprint import Rabin
import matplotlib.pyplot as plt
import os
class MicrobialGA():
    def __init__(self):
        self.polinomials = {
            2:  ["7"],
            3:  ["13"],
            4:  ["23"],
            5:  ["45", "75", "67"],
            6:  ["103", "147", "155"],
            7:  ["211", "217", "235", "367", "277", "325", "203", "313", "345"],
            8:  ["435", "551", "747", "453", "545", "537", "703", "543"],
            9:  ["1021", "1131", "1461", "1423", "1055", "1167", "1541","1333", "1605", "1751", "1743", "1617", "1553", "1157"],
            10: ["2011", "2415", "3771", "2157", "3515", "2773", "2033","2443", "2461", "3023", "3543", "2745", "2431", "3177"],
            11: ["4005", "4445", "4215", "4055", "6015", "7413", "4143", "4563", "4053", "5023", "5623", "4577", "6233", "6673"],
            12: ["10123", "15647", "16533", "16047", "11015", "14127","17673", "13565", "15341", "15053", "15621", "15321","11417", "13505"],
            13: ["20033", "23261", "24623", "23517", "30741", "21643","30171", "21277", "27777", "35051", "34723", "34047", "32535", "31425"],
            14: ["42103", "43333", "51761", "40503", "77141", "62677","44103", "45145", "76303", "64457", "57231", "64167","60153", "55753"],
            15: [ "100003", "102043", "110013", "102067", "104307", "100317","177775", "103451", "110075", "102061", "114725", "103251","100021", "100201"],
            16: ["210013", "234313", "233303", "307107", "307527", "306357","201735", "272201", "242413", "270155", "302157", "210205","305667", "236107"],
            17: ["400011", "400017", "400431", "525251", "410117", "400731","411335", "444257", "600013", "403555", "525327", "411077","400041", "400101"],
            18: ["1000201", "1000247", "1002241", "1002441", "1100045","1000407", "1003011", "1020121", "1101005", "1000077","1001361", "1001567", "1001727", "1002777"]
        }

        
    def trans_pol(self,octal_pol, degree):
        ##The table provides polynomils in octal form, ww need to transfere it to binary
        ##Ordinary bin(0o123) would loose primary bit if they are 0, so we need something more complicated
        octal_pol = octal_pol.replace("*", "")
        value = int(octal_pol, 8) 
        binary = bin(value)[2:]   #skipping 0b
       
        binary = binary.zfill(degree + 1)  
        poly = int(binary, 2)
        
        return poly



    def random_genotype(self,min,max):
        #Numbers are decided based on fingirprint values table. More details in the paper#
        window_degree = [4, 8, 12, 16, 18]
        pol_deg = [7, 11, 15, 17]
        mask_deg = [2, 4, 8, 12, 16, 18]
        

        rand_deg_pol=random.choice(pol_deg)
        rand_window_degree=random.choice(window_degree)
        
        rand_mask_deg=random.choice(mask_deg)
        
        polynomial = random.choice(self.polinomials[rand_deg_pol])
        polynomial=self.trans_pol(polynomial,rand_deg_pol)
        mask=(1 << rand_mask_deg) - 1
        genotype=[int(rand_deg_pol),int(polynomial),int(rand_window_degree),int(mask),min, max]
         
    
        return genotype
    
    def ffunction1(self,cand):
        ### activates rabin fingerprint. Percentage of saved space is fitness value
        rabin=Rabin()
        saved_space=rabin.start(cand)
        return saved_space
 
    def tournament_selection(self,pop_genotypes, pop_fitnesses):
        max_fit=max(pop_fitnesses)
        max_index=pop_fitnesses.index(max_fit)

        min_fit=min(pop_fitnesses)
        min_index=pop_fitnesses.index(min_fit)
        return max_index, min_index


    def microbial_selection(self,pop_genotypes, pop_fitnesses,D):
        #because of strange error AttributeError: module 'numpy.random' has no attribute 'randrange' I am using range
        A=random.choice(range(D))
        B=(A+random.randint(1,D))%len(pop_genotypes)## % to wrap around
        if pop_fitnesses[A]>pop_fitnesses[B]:
            win_index=A
            los_index=B
        else:
            win_index=B
            los_index=A
        print(f"the win is: {pop_genotypes[win_index]},{pop_fitnesses[win_index]}\nthe los is {pop_genotypes[los_index]},{pop_fitnesses[los_index]} ")
        return win_index,los_index

    def uniform_crossover(self,cand_loser, cand_winner, prob_csross, n_genes):
        copy_loser = cand_loser.copy()

        for i in range(n_genes):
            
                prob = random.uniform(0, 1)
                if prob < prob_csross:
                    ##It does not make sense to change polynomial degree without changing itself and viseversa
                    if i==0: #if copies degree of pol.-> randomly choose pol.
                        copy_loser[0] = cand_winner[0]
                        copy_loser[1]=random.choice(self.polinomials[cand_winner[0]])
                    elif i==1:# if copy pol. itself, then copy also degree
                        copy_loser[0] = cand_winner[0]
                        copy_loser[1]=cand_winner[1]

                    
                    copy_loser[i] = cand_winner[i]

        return copy_loser

    def micro_GA(self,fitness_tar,pop_size,p_mutation,microbial_max,min_size,max_size,D):
        best_fitness_hystory=[]
        pop_genotypes=[]
        pop_fitnesses=[]
        microbial_currrent=0
        fitness_best=0

        for i in range(pop_size-1):
            genotype=self.random_genotype(min_size,max_size)
            pop_genotypes.append(genotype)
            pop_fitnesses.append(self.ffunction1(genotype))
            
        
        while fitness_best<=fitness_tar and microbial_currrent<microbial_max:

            winner_index,loser_index=self.tournament_selection(pop_genotypes,pop_fitnesses)
            loser_copy=self.uniform_crossover(pop_genotypes[loser_index],pop_genotypes[winner_index],1/2,len(pop_genotypes[loser_index])-1)
            pop_genotypes[loser_index]=self.mutate_genotype(loser_copy,p_mutation)
            pop_fitnesses[loser_index]=self.ffunction1(pop_genotypes[loser_index])
            microbial_currrent+=1

            max_fit=max(pop_fitnesses)
            max_fit2=pop_fitnesses.index(max_fit)
            best_fitness_hystory.append(max_fit)


        

        return pop_genotypes,pop_fitnesses,best_fitness_hystory
    
    def mutate_genotype(self, genotype, p_mutation):
      
        
        window_sizes = [4, 8, 12, 16, 18]
        pol_degs = [7, 11, 15, 17]
        mask_degs = [2, 4, 8, 12, 16, 18]

        new_genotype = genotype.copy()
        

        ### Mutating the degree of polinomial
        #If polynimial degree was changed, new polynomial will obviouslt be creaeted alongside. If not 
        ## there is a chance of mutationg polynomial without changing its degree
        if random.random() < p_mutation:
            new_deg = random.choice(pol_degs[pol_degs != genotype[0]])
            if new_deg==0 or new_deg==1 :
                new_deg=2
            new_poly = random.choice(self.polinomials[new_deg])
            new_poly1 = self.trans_pol(new_poly, new_deg)

            new_genotype[0] = int(new_deg)
            new_genotype[1] = int(new_poly1)

        ### Mutating the polynomial
        if random.random() < p_mutation:
            new_poly = random.choice(self.polinomials[int(new_genotype[0])])
            new_poly1 = self.trans_pol(new_poly, int(new_genotype[0]))
            new_genotype[1] = int(new_poly1)
            
            

        ### Mutating the size of the window
        if random.random() < p_mutation:
            new_genotype[2] = int(random.choice(window_sizes))
            

        ### Mutating the mask
        if random.random() < p_mutation:
            #length of mask should always be less than degree of polynomial
            new_genotype[3] = int(random.choice(mask_degs))
            

         ### Mutating the minimal size of the chunk
        if random.random() < p_mutation:
            if random.random()<50:
                new_min = max(124, new_genotype[4] + 124)
            elif random.random()>50:
                new_min = max(124, new_genotype[4] - 124)

            if new_min < new_genotype[5]:
                new_genotype[4] = new_min
                

        ### Mutating the maximal size of the chunk
        if random.random() < p_mutation:
            if random.random()<50:
                new_max = new_genotype[5] + 124
            elif random.random()>50:
                new_max = new_genotype[5] - 124

            if new_max > new_genotype[4] + 124:
                new_genotype[5] = new_max
                

        return  new_genotype


    
    def netcrawler_accept(self,delta_f):
        if delta_f >= 0:
            return True
        else:
            return False

def generate_test_file(filename, total_size, duplicate_percent):
    duplicate_size = int(total_size * duplicate_percent / 100)

    blocks = []
    size = 0

   
    dup_block = os.urandom(64)
    

    while size < duplicate_size:
        blocks.append(dup_block)
        size += len(dup_block)
          

    while size < total_size:
        block = os.urandom(random.randint(1, 100))
        
        blocks.append(block)
        size += len(block)
         

  
    random.shuffle(blocks)
    file_path = os.path.join('files', filename)

    with open(file_path, "wb") as f:
        f.write(b"".join(blocks))
    

    


def main():
    generate_test_file('testfile.pdf',150*1024,30)


    microbialGA=MicrobialGA()
    p_mutation1 = 1 / 2
   
    cand=microbialGA.random_genotype(1024,6144)
    
    # genotype=[int(rand_deg_pol),int(polynomial),int(rand_window_degree),int(mask),min, max]

    """cand_best1, fitness_best1,fitness_history,positive_mutations = microbialGA.generalised_hill_climber(
        fitness_target=100,
        iteration_max=number_of_generations,
        p_mutation=p_mutation1,
        cand=cand,
    )"""
    pop_best, fitnesses,fitness_history=microbialGA.micro_GA(
        fitness_tar=100,
        pop_size=10,
        p_mutation=p_mutation1,
        microbial_max=200,
        min_size=64,
        max_size=6144,
        D=5
    )

    winner_index,loser_index=microbialGA.microbial_selection(pop_best,fitnesses,D=5)
    print("Population is\n")
    for i in range(len(pop_best)):
        print(f"{pop_best[i]} it's fitness is {fitnesses[i]}")

    max_fit=max(fitnesses)
    max_index=fitnesses.index(max_fit)
   
    
    print(f"Original candidate is {cand}, it's fitness is {microbialGA.ffunction1(cand)}")
    print(f"The best cand is {pop_best[max_index]}, it's fitness is {max_fit}, index {max_index}")

    plt.figure(figsize=(8,5))
    plt.plot(range(1, len(fitness_history)+1), fitness_history, marker='o')
    plt.xlabel("Iterations")
    plt.ylabel("Fitness")
    plt.title("Fitness over iterations")
    plt.grid(True)
    plt.show()

    


if __name__ == "__main__":
   
    main()


